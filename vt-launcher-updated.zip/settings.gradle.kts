rootProject.name = "vt-launcher"
