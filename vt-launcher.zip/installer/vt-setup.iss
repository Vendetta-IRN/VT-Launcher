; VT Launcher setup (built with Inno Setup). The version is passed in by the build: /DAppVersion=x.y.z
#ifndef AppVersion
  #define AppVersion "0.0.0"
#endif

[Setup]
AppId={{A3D5C6E2-5B7F-4C1E-9F6A-2B8D4E7F1C90}
AppName=VT Launcher
AppVersion={#AppVersion}
AppPublisher=VT
DefaultDirName={localappdata}\Programs\VT Launcher
DefaultGroupName=VT Launcher
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=..\installer-out
OutputBaseFilename=VT-Launcher-Setup-v{#AppVersion}
SetupIconFile=..\src\main\resources\vt\vt.ico
UninstallDisplayIcon={app}\VT Launcher.exe
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
WizardImageFile=wizard-large.bmp
WizardSmallImageFile=wizard-small.bmp
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "..\out\VT Launcher\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\VT Launcher"; Filename: "{app}\VT Launcher.exe"
Name: "{autodesktop}\VT Launcher"; Filename: "{app}\VT Launcher.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\VT Launcher.exe"; Description: "{cm:LaunchProgram,VT Launcher}"; Flags: nowait postinstall skipifsilent
