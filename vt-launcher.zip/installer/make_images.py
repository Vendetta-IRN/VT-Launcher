"""Draws the setup artwork (dark red / black, with the launcher logo) for the installer."""
import os
from PIL import Image, ImageDraw, ImageFont

here = os.path.dirname(os.path.abspath(__file__))
logo_path = os.path.join(here, "..", "src", "main", "resources", "vt", "logo.png")


def font(size, bold=False):
    for name in (("segoeuib.ttf" if bold else "segoeui.ttf"), "arialbd.ttf" if bold else "arial.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except Exception:
            pass
    return ImageFont.load_default()


def gradient(w, h, top=(122, 10, 20), bottom=(14, 14, 18)):
    img = Image.new("RGB", (w, h))
    d = ImageDraw.Draw(img)
    for y in range(h):
        t = y / max(1, h - 1)
        d.line([(0, y), (w, y)], fill=tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3)))
    return img


logo = Image.open(logo_path).convert("RGBA")

# large image (left side of the first and last page)
big = gradient(164, 314)
size = 108
lg = logo.resize((size, size), Image.LANCZOS)
big.paste(lg, ((164 - size) // 2, 56), lg)
d = ImageDraw.Draw(big)
title = "VT Launcher"
f = font(20, True)
w = d.textlength(title, font=f)
d.text(((164 - w) / 2, 180), title, font=f, fill=(255, 255, 255))
sub = "Minecraft Java launcher"
f2 = font(11)
w2 = d.textlength(sub, font=f2)
d.text(((164 - w2) / 2, 210), sub, font=f2, fill=(220, 190, 195))
big.save(os.path.join(here, "wizard-large.bmp"), "BMP")

# small image (top right of the other pages)
small = Image.new("RGB", (55, 55), (14, 14, 18))
lg2 = logo.resize((44, 44), Image.LANCZOS)
small.paste(lg2, (5, 5), lg2)
small.save(os.path.join(here, "wizard-small.bmp"), "BMP")
print("setup images ready")
